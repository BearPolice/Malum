using Terraria.ModLoader;

namespace Malum
{
	class Malum : Mod
	{
		public Malum()
		{
		}
	}
}
